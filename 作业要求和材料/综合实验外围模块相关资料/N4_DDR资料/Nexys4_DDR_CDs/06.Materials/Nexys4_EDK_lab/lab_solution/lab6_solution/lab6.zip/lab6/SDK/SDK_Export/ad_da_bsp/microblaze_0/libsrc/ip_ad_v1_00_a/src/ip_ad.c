/*****************************************************************************
* Filename:          E:\Project\N4\lab6/drivers/ip_ad_v1_00_a/src/ip_ad.c
* Version:           1.00.a
* Description:       ip_ad Driver Source File
* Date:              Tue Nov 26 09:55:46 2013 (by Create and Import Peripheral Wizard)
*****************************************************************************/


/***************************** Include Files *******************************/

#include "ip_ad.h"

/************************** Function Definitions ***************************/

