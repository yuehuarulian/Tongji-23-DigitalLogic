/*
 * seg.c
 *
 *  Created on: 2013-11-26
 *      Author: tp
 */

#include "xparameters.h"
#include "xgpio.h"
#include "xil_io.h"
#include "xil_printf.h"


XGpio Gpio,Gpio1;


int select(int m);


int main(void)
{

	int Status1,Status2,i,p,q,temp1,temp2;

	Status1 = XGpio_Initialize(&Gpio, XPAR_AXI_GPIO_0_DEVICE_ID);
	if (Status1 != XST_SUCCESS) {
		return XST_FAILURE;
	}

	Status2 = XGpio_Initialize(&Gpio1, XPAR_LED_7SEGMENT_DEVICE_ID);
		if (Status2 != XST_SUCCESS) {
			return XST_FAILURE;
		}
    XGpio_SetDataDirection(&Gpio, 0x1, 0);

    while(1)
    {
    	for(p=0;p<10;p++)
    	{
    		temp2=select(p);

    	for(q=0;q<100;q++)
    	   {
    			XGpio_DiscreteWrite(&Gpio1, 0x1, temp2);
    	    	XGpio_DiscreteWrite(&Gpio, 0x1, 0xfd);
    	    	for(i=0;i<60000;i++);
    	    	temp1=select(q/10);

    	    	XGpio_DiscreteWrite(&Gpio1, 0x1, temp1);
    	    	XGpio_DiscreteWrite(&Gpio, 0x1, 0xfe);
    	    	for(i=0;i<60000;i++);


    	    }
    }
    }

	return XST_SUCCESS;

}
int select(int m)
{
	int temp=0;
	switch(m)
	{
	case 0:
		temp=0b0000001;
		break;
	case 1:
		temp=0b1001111;
		break;
	case 2:
		temp=0b0010010;
		break;
	case 3:
		temp=0b0000110;
		break;
	case 4:
		temp=0b1001100;
		break;
	case 5:
		temp=0b0100100;
		break;
	case 6:
		temp=0b0100000;
		break;
	case 7:
		temp=0b0001111;
		break;
	case 8:
		temp=0b0000000;
		break;
	case 9:
		temp=0b0000100;
		break;
	default:
		temp=0b0000001;
		break;
	}
	return temp;

}
